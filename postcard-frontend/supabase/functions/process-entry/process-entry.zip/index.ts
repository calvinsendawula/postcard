// Follow this setup guide to integrate the Deno language server with your editor:
// https://deno.land/manual/getting_started/setup_your_environment
// This enables autocomplete, go to definition, etc.

// Setup type definitions for built-in Supabase Runtime APIs
import "jsr:@supabase/functions-js/edge-runtime.d.ts"
import { createClient } from 'jsr:@supabase/supabase-js@^2';
import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";

// TODO: Replace with actual Gemini client/API calls

console.log("Initializing process-entry function v3");

const GEMINI_MODEL_TEXT = "gemini-2.0-flash"; // Using specified Gemini Flash model
const GEMINI_MODEL_EMBEDDING = "text-embedding-001"; // Using specified embedding model
const EMBEDDING_DIMENSIONS = 384; // Ensure this matches the DB column

// Define the expected structure for relationship inserts
interface RelationshipInsert {
  entry_id: string;
  entity_id: string;
  relationship_type: string;
}

// Basic safety settings for Gemini
const safetySettings = [
  { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
  { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
  { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
  { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
];

Deno.serve(async (req) => {
  try {
    console.log("Function invoked");
    const payload = await req.json();
    // Handle both direct invocation ({ record: ... }) and webhook ({ type: 'INSERT', record: ... })
    const record = payload?.record ?? (payload?.type === 'INSERT' ? payload.record : null);
    const entryId = record?.id;

    if (!entryId) throw new Error("Missing entry ID in payload");
    console.log(`Processing entry ID: ${entryId}`);

    // --- Get Environment Variables --- 
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const geminiApiKey = Deno.env.get("GEMINI_API_KEY");

    if (!supabaseUrl || !supabaseServiceKey || !geminiApiKey) {
      console.error("Missing environment variables:", { supabaseUrl: !!supabaseUrl, supabaseServiceKey: !!supabaseServiceKey, geminiApiKey: !!geminiApiKey });
      throw new Error("Missing required environment variables.");
    }
    console.log("Environment variables loaded");

    // --- Initialize Clients --- 
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const genAI = new GoogleGenerativeAI(geminiApiKey);
    const textModel = genAI.getGenerativeModel({ model: GEMINI_MODEL_TEXT, safetySettings });
    const embeddingModel = genAI.getGenerativeModel({ model: GEMINI_MODEL_EMBEDDING });
    console.log("Clients initialized");

    // --- Fetch Raw Text --- 
    const { data: entryData, error: fetchError } = await supabase
      .from('entries')
      .select('id, raw_text')
      .eq('id', entryId)
      .single();

    if (fetchError) {
      console.error("Error fetching entry:", fetchError);
      throw fetchError;
    }
    if (!entryData) throw new Error(`Entry not found for ID: ${entryId}`);
    const rawText = entryData.raw_text;
    if (!rawText) {
        console.log("Entry has empty raw_text, skipping processing.");
        return new Response(JSON.stringify({ success: true, entryId, message: "Skipped empty entry" }), {
          headers: { "Content-Type": "application/json" }, status: 200
        });
    }
    console.log(`Fetched raw text: "${rawText.substring(0, 100)}..."`);

    // --- Generate Embedding --- 
    console.log(`Generating embedding using ${GEMINI_MODEL_EMBEDDING}...`);
    const embeddingResult = await embeddingModel.embedContent(rawText);
    const embedding = embeddingResult.embedding.values;
    if (!embedding || embedding.length !== EMBEDDING_DIMENSIONS) {
        throw new Error(`Failed to generate valid embedding of dimension ${EMBEDDING_DIMENSIONS}`);
    }
    console.log(`Generated embedding: [${embedding.slice(0, 3)}...]`);

    // --- Generate Refined Text, Entities, and Relationships --- 
    console.log(`Generating structured data using ${GEMINI_MODEL_TEXT}...`);
    const prompt = `Analyze the following developer note:\n\"\"\"\n${rawText}\n\"\"\"\n\nBased ONLY on the text provided, perform the following tasks:\n1.  **Refine Text:** Rewrite the note into clear, structured documentation suitable for a knowledge base. Use markdown formatting (like headings, lists, code blocks if appropriate). If the input is already well-structured, just return it.\n2.  **Extract Entities:** Identify key entities (projects, technologies, components, concepts, people, bug IDs, etc.) mentioned. For each entity, provide its name and a general type (e.g., 'project', 'technology', 'concept', 'person', 'bug_id').\n3.  **Extract Relationships:** Describe the relationships between the identified entities *within the context of this note*. For example: \"Entity A uses Technology B\", \"Entity C fixes Bug D\".\n\nFormat the output STRICTLY as a JSON object with the following keys:\n- \"processed_text\": (string) The refined documentation text.\n- \"entities\": (array of objects) Each object should have \"name\" (string) and \"type\" (string).\n- \"relationships\": (array of objects) Each object should have \"subject_entity\" (string), \"relationship_type\" (string), and \"object_entity\" (string).\n\nExample output format:\n{\n  \"processed_text\": \"### Authentication Flow Bug Fix\\n\\n- **Issue:** Annoying bug in the authentication flow.\\n- **Solution:** Added proper error handling to the login form component.\\n- **Details:** Ensured all edge cases return user-friendly messages.\",\n  \"entities\": [\n    { \"name\": \"authentication flow\", \"type\": \"concept\" },\n    { \"name\": \"login form\", \"type\": \"component\" },\n    { \"name\": \"error handling\", \"type\": \"concept\" }\n  ],\n  \"relationships\": [\n    { \"subject_entity\": \"login form\", \"relationship_type\": \"received\", \"object_entity\": \"error handling\" },\n    { \"subject_entity\": \"error handling\", \"relationship_type\": \"fixed\", \"object_entity\": \"authentication flow\" }\n  ]\n}\n\nIf no entities or relationships can be reliably extracted from the text, return empty arrays for those keys. Provide only the JSON object in your response.`;

    const generationConfig = {
      responseMimeType: "application/json",
    };

    const generationResult = await textModel.generateContent(prompt, generationConfig);
    const responseText = generationResult.response.text();
    let structuredData;
    try {
      structuredData = JSON.parse(responseText);
    } catch (parseError) {
      console.error("Failed to parse Gemini JSON response:", responseText, parseError);
      throw new Error("Failed to parse AI response as JSON.");
    }

    const processed_text = structuredData.processed_text || rawText; // Fallback to raw text if processing fails
    const extractedEntities = structuredData.entities || [];
    // const extractedRelationships = structuredData.relationships || []; // Keep for potential future use

    console.log(`Processed text generated: "${processed_text.substring(0, 100)}..."`);
    console.log(`Extracted entities:`, extractedEntities.length);

    // --- Update Database Entry --- 
    console.log("Updating entry with processed text and embedding...");
    const { error: updateError } = await supabase
      .from('entries')
      .update({ processed_text, embedding })
      .eq('id', entryId);

    if (updateError) {
      console.error("Error updating entry:", updateError);
      throw updateError;
    }
    console.log(`Successfully updated entry ${entryId}.`);

    // --- Upsert Entities and Create Simplified 'Mentions' Relationships --- 
    console.log("Processing entities and relationships...");
    const entityMap = new Map<string, string>(); // Map entity name to DB ID

    if (extractedEntities.length > 0) {
      for (const entity of extractedEntities) {
        // Basic validation
        if (!entity.name || typeof entity.name !== 'string' || !entity.type || typeof entity.type !== 'string') {
            console.warn("Skipping invalid entity format:", entity);
            continue;
        }
        try {
            const { data: upsertedEntityData, error: entityUpsertError } = await supabase
                .from('entities')
                .upsert({ name: entity.name.trim(), type: entity.type.trim() }, { onConflict: 'name' })
                .select('id, name')
                .single();

            if (entityUpsertError) {
                console.error(`Error upserting entity '${entity.name}':`, entityUpsertError);
                continue;
            }
            console.log(`Upserted entity: ${upsertedEntityData?.name} with ID: ${upsertedEntityData?.id}`);
            if (upsertedEntityData?.id && upsertedEntityData?.name) {
                entityMap.set(upsertedEntityData.name, upsertedEntityData.id);
            }
        } catch (upsertCatchError) {
            console.error(`Caught exception during upsert for entity '${entity.name}':`, upsertCatchError);
        }
      }
    }

    // Create relationships using the IDs from entityMap
    if (entityMap.size > 0) {
        // Explicitly type the array to help TypeScript/linter
        const relationshipInserts: RelationshipInsert[] = []; 
        for (const entityId of entityMap.values()) { // Iterate over IDs directly
            relationshipInserts.push({
                entry_id: entryId,
                entity_id: entityId,
                relationship_type: 'mentions' // Simplified relationship type
            });
        }

        if (relationshipInserts.length > 0) {
            console.log(`Inserting ${relationshipInserts.length} 'mentions' relationships...`);
            const { error: relationshipError } = await supabase
                .from('relationships')
                .insert(relationshipInserts, { upsert: true, onConflict: 'entry_id,entity_id,relationship_type' });

            if (relationshipError) {
                 // Log non-duplicate errors
                if (relationshipError.code !== '23505') { // Ignore unique violation errors on upsert
                     console.error(`Error inserting relationships:`, relationshipError);
                } else {
                    console.log("Relationship upsert completed (duplicates handled).");
                }
            } else {
                console.log("Successfully inserted/upserted relationships.");
            }
        }
    }

    console.log(`Processing complete for entry ${entryId}.`);
    return new Response(JSON.stringify({ success: true, entryId }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error("Error in process-entry function:", error);
    return new Response(JSON.stringify({ error: error.message || 'Internal Server Error' }), {
      headers: { "Content-Type": "application/json" },
      status: 500,
    });
  }
});

/* To invoke locally:

  1. Run `supabase start` (see: https://supabase.com/docs/reference/cli/supabase-start)
  2. Make an HTTP request:

  curl -i --location --request POST 'http://127.0.0.1:54321/functions/v1/process-entry' \
    --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0' \
    --header 'Content-Type: application/json' \
    --data '{"name":"Functions"}'

*/
